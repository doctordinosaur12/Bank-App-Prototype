package objects;
import java.sql.Date;
import java.util.*;
import java. sql.Time;
public class Main 
{

	public static void main(String[] args) 
	{
		
		java.sql.Date date = new java.sql.Date(Calendar.getInstance().getTime().getTime());
		java.sql.Time time = new Time(System.currentTimeMillis());
		
		//Customer john = new Customer();
		//john.newCustomer(01111,"elliot", "mar", date,0);
		//john.updateCustomer(42765, "Grace", "Williams", date, 760);
		//john.deleteCustomer(42765);
		
		//Order order = new Order();
		//order.newOrder(date, time, 0123415);
		//order.updateOrder(1, date, time, 01111);
		//order.deleteOrder(4);
		
		//Professor john = new Professor();
		//john.updateProfessor(42765, "science", "office 2", "chairs");
		
		//Student john = new Student();
		//john.updateStudent(42765, date , date, "computer science", "none");
		
		//HistoricalPrice test = new HistoricalPrice();
		//test.newHistoricalPrice(10.52, date, 1111);
		
		//MenuItem food = new MenuItem();
		//food.newMenuItem("burger", 5);
		//food.updateMenuItem(1, "fries", 5);
		//food.deleteMenuItem(1);
		
		//Food_Order test = new Food_Order();
		//test.newFoodOrder(2, 2, 3);
		//test.deleteFoodOrder(2, 2);
		
	}

}
