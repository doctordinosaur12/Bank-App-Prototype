package control;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import java.util.ArrayList;


public class OrderController extends HttpServlet{
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req,resp);
	}
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String address = "/OrderView.jsp";
		Food hotdog = new Food("Hotdog",5.5);
		Food soda = new Food("Soda",5);
		ArrayList<Food> foods = new ArrayList<Food>();
		foods.add(hotdog);
		foods.add(soda);
		req.setAttribute("foods",foods);
		

		
		double total = Integer.parseInt(req.getParameter("quantity1")) * 5.5 + Integer.parseInt(req.getParameter("quantity2")) * 5;
		req.setAttribute("total", total);
		req.setAttribute("quantity1",req.getParameter("quantity1"));
		req.setAttribute("quantity2",req.getParameter("quantity2"));
		
		RequestDispatcher rd = req.getRequestDispatcher(address);
		rd.forward(req, resp);
	}
}
